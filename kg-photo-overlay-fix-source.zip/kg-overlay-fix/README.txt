KG App photo overlay fix

Replace these files in the existing repository:
- app/src/main/AndroidManifest.xml
- app/src/main/java/com/example/morsehorror/MainActivity.java
Add:
- app/src/main/java/com/example/morsehorror/OverlayService.java

Keep the existing app/src/main/assets/horror.png and music_kg.mp3 files.

The old MainActivity only showed the photo inside the app; it did not create a system overlay. This change uses WindowManager.TYPE_APPLICATION_OVERLAY and includes an always-visible X close button. The close button also stops the music. The overlay starts only after the user opens the app and grants the Android permission.

After committing these files to the main branch, GitHub Actions should build a new APK. Download the app-debug-apk artifact from the newest successful Build APK run. This patch itself is source code, not an APK.
